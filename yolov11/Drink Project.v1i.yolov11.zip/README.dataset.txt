# Drink Project > 2024-12-20 10:41pm
https://universe.roboflow.com/wilsoncai/drink-project

Provided by a Roboflow user
License: CC BY 4.0

